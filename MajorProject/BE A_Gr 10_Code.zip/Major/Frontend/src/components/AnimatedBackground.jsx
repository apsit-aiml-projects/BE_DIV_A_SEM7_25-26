import React from "react";

export default function AnimatedBackground() {
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      {/* Gradient base */}
      <div className="absolute inset-0 animated-gradient" />

      {/* Soft beams */}
      <div className="absolute -inset-1 opacity-60 blur-3xl mix-blend-screen">
        <div className="beam beam-1" />
        <div className="beam beam-2" />
        <div className="beam beam-3" />
      </div>

      {/* Subtle noise for texture */}
      <div className="absolute inset-0 bg-noise opacity-[0.06]" />
    </div>
  );
}


