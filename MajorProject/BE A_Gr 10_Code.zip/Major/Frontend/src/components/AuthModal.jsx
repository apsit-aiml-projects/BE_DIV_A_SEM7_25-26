import React, { useState } from "react";
import { useAuthModal, Button, Card, CardHeader, CardTitle, CardContent } from "../main.jsx";
import { LogIn } from "lucide-react";

export default function AuthModal() {
  const { open, closeModal, mode, setMode, signIn } = useAuthModal();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  if (!open) return null;

  const submit = (e) => {
    e.preventDefault();
    if (!/\S+@\S+\.\S+/.test(email)) return alert("Please enter a valid email.");
    if (password.length < 6) return alert("Password must be at least 6 characters.");
    if (mode === "signup") {
      if (!name.trim()) return alert("Please enter your name.");
      if (confirm !== password) return alert("Passwords do not match.");
      signIn({ email, name });
    } else {
      signIn({ email });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={closeModal} />
      <Card className="relative w-full max-w-md">
        <CardHeader>
          <CardTitle>
            {mode === "signin" ? "Sign in to continue" : "Create your account"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4 flex rounded-md overflow-hidden border border-border">
            <button
              onClick={() => setMode("signin")}
              className={`flex-1 py-2 text-sm ${mode === "signin" ? "btn-gradient text-white" : "hover:bg-input"}`}
            >
              Sign in
            </button>
            <button
              onClick={() => setMode("signup")}
              className={`flex-1 py-2 text-sm ${mode === "signup" ? "btn-gradient text-white" : "hover:bg-input"}`}
            >
              Sign up
            </button>
          </div>
          <form onSubmit={submit} className="space-y-3">
            {mode === "signup" && (
              <div>
                <label className="text-sm">Name</label>
                <input
                  type="text"
                  className="mt-1 w-full rounded-md bg-input border border-border px-3 py-2 outline-none focus:ring-2 focus:ring-ring"
                  placeholder="Your name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
            )}
            <div>
              <label className="text-sm">Email</label>
              <input
                type="email"
                className="mt-1 w-full rounded-md bg-input border border-border px-3 py-2 outline-none focus:ring-2 focus:ring-ring"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoFocus
              />
            </div>
            <div>
              <label className="text-sm">Password</label>
              <input
                type="password"
                className="mt-1 w-full rounded-md bg-input border border-border px-3 py-2 outline-none focus:ring-2 focus:ring-ring"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            {mode === "signup" && (
              <div>
                <label className="text-sm">Confirm password</label>
                <input
                  type="password"
                  className="mt-1 w-full rounded-md bg-input border border-border px-3 py-2 outline-none focus:ring-2 focus:ring-ring"
                  placeholder="••••••••"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                />
              </div>
            )}
            <Button type="submit" className="w-full">
              <LogIn size={16} />
              {mode === "signin" ? "Sign in" : "Create account"}
            </Button>
            <p className="text-xs text-muted">
              This is a demo. Any email/password passes basic validation.
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}


