import React from "react";

export default function Footer() {
  return (
    <footer className="mt-16 border-t border-border">
      <div className="container-flo max-w-6xl grid grid-cols-1 md:grid-cols-4 gap-8 py-10">
        <div>
          <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">M</span>
          </div>
            <span className="font-semibold">Meet Summarizer</span>
          </div>
          <p className="text-sm text-muted">
            Turn meetings into crisp summaries, action items, and decisions.
          </p>
        </div>
        <div>
          <h4 className="font-semibold mb-3">Product</h4>
          <ul className="space-y-2 text-sm text-muted">
            <li><a href="#features" className="hover:opacity-80">Features</a></li>
            <li><a href="/app" className="hover:opacity-80">App</a></li>
            <li><a href="#" className="hover:opacity-80">Changelog</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-3">Resources</h4>
          <ul className="space-y-2 text-sm text-muted">
            <li><a href="#" className="hover:opacity-80">Docs</a></li>
            <li><a href="#" className="hover:opacity-80">Guides</a></li>
            <li><a href="#" className="hover:opacity-80">FAQ</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-3">About</h4>
          <ul className="space-y-2 text-sm text-muted">
            <li><a href="#" className="hover:opacity-80">Company</a></li>
            <li><a href="#" className="hover:opacity-80">Open roles</a></li>
            <li><a href="#" className="hover:opacity-80">Contact</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border py-4 text-xs text-center text-muted">
        © {new Date().getFullYear()} Meet Summarizer. All rights reserved.
      </div>
    </footer>
  );
}


