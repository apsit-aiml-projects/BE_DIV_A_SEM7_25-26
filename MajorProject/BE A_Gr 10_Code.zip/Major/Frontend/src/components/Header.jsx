import React, { useEffect, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import { useAuthModal, useTheme } from "../main.jsx";

function useScrolled(offset = 8) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > offset);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [offset]);
  return scrolled;
}

export default function Header() {
  const scrolled = useScrolled(10);
  const { isAuthenticated, signOut, user } = useAuthModal();
  const { theme, toggle } = useTheme();

  return (
    <header
      className={`sticky top-0 z-40 transition-all ${
        scrolled ? "glass border-b" : "bg-transparent"
      }`}
    >
      <div className="container-flo max-w-6xl flex items-center justify-between py-3">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold text-sm">M</span>
          </div>
          <span className="font-bold text-lg text-gradient">Meet Summarizer</span>
        </Link>
        <nav className="hidden md:flex items-center gap-6">
          <a href="/" className="text-sm hover:opacity-80">Home</a>
          <a href="#features" className="text-sm hover:opacity-80">Features</a>
          <a href="#how" className="text-sm hover:opacity-80">How it Works</a>
          <NavLink to="/app" className="text-sm hover:opacity-80">App</NavLink>
        </nav>
        <div className="flex items-center gap-2">
          <button
            onClick={toggle}
            className="text-sm px-3 py-2 rounded-md hover:bg-input"
            title="Toggle theme"
          >
            {theme === "dark" ? "🌙" : "☀️"}
          </button>
          {!isAuthenticated ? (
            <NavLink
              to="/app"
              className="btn-gradient text-sm px-4 py-2 rounded-md text-white"
            >
              Get started
            </NavLink>
          ) : (
            <button
              onClick={signOut}
              className="text-sm px-4 py-2 rounded-md hover:bg-input"
              title="Sign out"
            >
              {user?.name || "User"} · Sign out
            </button>
          )}
        </div>
      </div>
    </header>
  );
}


