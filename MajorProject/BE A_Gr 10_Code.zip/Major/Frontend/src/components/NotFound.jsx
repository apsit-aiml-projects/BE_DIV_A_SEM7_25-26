import React from "react";
import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="py-24 text-center">
      <div className="text-6xl font-extrabold text-gradient mb-4">404</div>
      <p className="text-muted mb-6">The page you’re looking for doesn’t exist.</p>
      <Link to="/" className="btn-gradient text-white px-4 py-2 rounded-md">
        Go home
      </Link>
    </div>
  );
}


