import React, { createContext, useContext, useMemo, useState, useCallback, useEffect } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { LogIn, LogOut, Check, Copy, FileText, FileDown, Printer } from "lucide-react";
import "./index.css";

// UI helpers
function cn(...classes) {
  return classes.filter(Boolean).join(" ");
}

// Tiny UI primitives
export function Button({ className = "", variant = "default", onClick, disabled, children, type = "button" }) {
  const base =
    "inline-flex items-center gap-2 rounded-md text-sm font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50 disabled:pointer-events-none";
  const styles = {
    default: "bg-primary text-white hover:opacity-90 px-4 py-2",
    ghost: "bg-transparent hover:bg-input text-foreground px-3 py-2",
    outline: "border border-border bg-transparent hover:bg-input px-4 py-2",
    subtle: "bg-input hover:bg-opacity-70 px-4 py-2"
  };
  return (
    <button type={type} className={cn(base, styles[variant], className)} onClick={onClick} disabled={disabled}>
      {children}
    </button>
  );
}

export function Card({ className = "", children }) {
  return <div className={cn("glass rounded-lg", className)}>{children}</div>;
}
export function CardHeader({ className = "", children }) {
  return <div className={cn("px-5 py-4 border-b border-border", className)}>{children}</div>;
}
export function CardTitle({ className = "", children }) {
  return <h3 className={cn("text-lg font-semibold", className)}>{children}</h3>;
}
export function CardContent({ className = "", children }) {
  return <div className={cn("p-5", className)}>{children}</div>;
}
export function Textarea({ className = "", value, onChange, placeholder, rows = 8 }) {
  return (
    <textarea
      className={cn(
        "w-full rounded-md bg-input/70 border border-border px-3 py-2 outline-none focus:ring-2 focus:ring-ring",
        className
      )}
      rows={rows}
      value={value}
      onChange={onChange}
      placeholder={placeholder}
    />
  );
}
export function Progress({ value = 0 }) {
  return (
    <div className="w-full h-2 rounded-full bg-input overflow-hidden">
      <div
        className="h-full rounded-full btn-gradient transition-all"
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  );
}

// Theme + Auth Contexts (state only lives here)
const AuthModalContext = createContext(null);
const ThemeContext = createContext(null);

export function useAuthModal() {
  const ctx = useContext(AuthModalContext);
  if (!ctx) throw new Error("useAuthModal must be used within AuthModalProvider");
  return ctx;
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme must be used within ThemeProvider");
  return ctx;
}

function AuthModalProvider({ children }) {
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState("signin"); // 'signin' | 'signup'
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null); // {name, email}
  const signIn = useCallback((payload) => {
    // payload: { email, name? }
    const name = payload?.name || (payload?.email ? payload.email.split("@")[0] : "User");
    setUser({ name, email: payload?.email || "" });
    setIsAuthenticated(true);
    setOpen(false);
  }, []);
  const signOut = useCallback(() => {
    setIsAuthenticated(false);
    setUser(null);
  }, []);
  const value = useMemo(
    () => ({
      open,
      mode,
      isAuthenticated,
      user,
      openModal: (m = "signin") => {
        setMode(m);
        setOpen(true);
      },
      closeModal: () => setOpen(false),
      setMode,
      signIn,
      signOut
    }),
    [open, mode, isAuthenticated, user, signIn, signOut]
  );
  return <AuthModalContext.Provider value={value}>{children}</AuthModalContext.Provider>;
}

function ThemeProvider({ children }) {
  const [theme, setTheme] = useState("dark");
  useEffect(() => {
    const stored = localStorage.getItem("theme");
    if (stored === "light" || stored === "dark") setTheme(stored);
  }, []);
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
  }, [theme]);
  const toggle = useCallback(() => setTheme((t) => (t === "dark" ? "light" : "dark")), []);
  const value = useMemo(() => ({ theme, toggle }), [theme, toggle]);
  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

// Text helpers and summarizer
const STOPWORDS = new Set(
  "a,an,the,and,or,but,if,then,else,when,at,by,for,in,of,on,to,with,without,about,into,over,after,before,from,up,down,so,as,than,too,very,can,could,should,would,is,are,was,were,be,been,being,do,does,did,doing,has,have,had,having".split(",")
);

function tokenize(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s']/g, " ")
    .split(/\s+/)
    .filter(Boolean);
}

function splitSentences(text) {
  return text
    .replace(/\r/g, "")
    .split(/(?<=[\.?\!])\s+|\n+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

function wordFrequencies(tokens) {
  const freq = new Map();
  for (const t of tokens) {
    if (STOPWORDS.has(t)) continue;
    freq.set(t, (freq.get(t) || 0) + 1);
  }
  return freq;
}

function scoreSentence(sentence, freq) {
  const tokens = tokenize(sentence);
  let score = 0;
  for (const t of tokens) {
    if (freq.has(t)) score += freq.get(t);
  }
  return score / Math.sqrt(tokens.length + 1);
}

export function summarizeText(input, { ratio = 0.25, tone = "neutral" } = {}) {
  if (!input || !input.trim()) return "";
  const sentences = splitSentences(input);
  if (sentences.length <= 3) return input;
  const tokens = tokenize(input);
  const freq = wordFrequencies(tokens);
  const scored = sentences.map((s, i) => ({ i, s, score: scoreSentence(s, freq) }));
  const keep = Math.max(1, Math.floor(sentences.length * ratio));
  const top = scored.sort((a, b) => b.score - a.score).slice(0, keep).sort((a, b) => a.i - b.i);
  let summary = top.map((x) => x.s).join(" ");

  if (tone === "concise") {
    summary = summary.replace(/\b(very|really|basically|actually|just)\b/gi, "").replace(/\s+/g, " ");
  } else if (tone === "detailed") {
    summary += " Key points were highlighted and responsibilities clarified.";
  }
  return summary.trim();
}

export function extractActionItems(text) {
  if (!text) return [];
  const lines = text.split(/\n+/);
  const kws = /(will|should|need to|follow up|assign|due|next step|please)/i;
  return lines.filter((l) => kws.test(l)).map((l) => l.trim());
}

export function extractDecisions(text) {
  if (!text) return [];
  const lines = text.split(/\n+/);
  const kws = /(decided|agreed|approved|chose|concluded|finalized)/i;
  return lines.filter((l) => kws.test(l)).map((l) => l.trim());
}

// Subtitle parsers
export function parseSRT(s) {
  const blocks = s.replace(/\r/g, "").split(/\n{2,}/);
  const out = [];
  for (const b of blocks) {
    const lines = b.split("\n").filter(Boolean);
    if (lines.length >= 2) {
      const first = lines[0];
      const hasIndex = /^\d+$/.test(first);
      const textLines = hasIndex ? lines.slice(2) : lines.slice(1);
      out.push(textLines.join(" "));
    }
  }
  return out.join("\n");
}

export function parseVTT(s) {
  const cleaned = s.replace(/\r/g, "").replace(/^WEBVTT.*\n/, "");
  const blocks = cleaned.split(/\n{2,}/);
  const out = [];
  for (const b of blocks) {
    const lines = b.split("\n").filter(Boolean);
    if (!lines.length) continue;
    const textLines = lines.filter((ln) => !/-->\s*/.test(ln));
    if (textLines.length) out.push(textLines.join(" "));
  }
  return out.join("\n");
}

// Layout shell imports
import Header from "./components/Header.jsx";
import Footer from "./components/Footer.jsx";
import NotFound from "./components/NotFound.jsx";
import Landing from "./pages/Landing.jsx";
import AppMain from "./pages/AppMain.jsx";
import AnimatedBackground from "./components/AnimatedBackground.jsx";

function ScrollToTop() {
  const [_, force] = useState(0);
  useEffect(() => {
    const onPop = () => force((n) => n + 1);
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);
  useEffect(() => {
    window.scrollTo(0, 0);
  });
  return null;
}

function AppLayout({ children }) {
  return (
    <div className="min-h-screen flex flex-col relative">
      <AnimatedBackground />
      <Header />
      <main className="flex-1">
        <div className="container-flo max-w-6xl">{children}</div>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  const queryClient = useMemo(() => new QueryClient(), []);
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <AuthModalProvider>
          <BrowserRouter>
            <ScrollToTop />
            <AnimatePresence mode="wait">
              <Routes>
                <Route
                  path="/"
                  element={
                    <AppLayout>
                      <Landing />
                    </AppLayout>
                  }
                />
                <Route
                  path="/app"
                  element={
                    <AppLayout>
                      <AppMain />
                    </AppLayout>
                  }
                />
                <Route
                  path="*"
                  element={
                    <AppLayout>
                      <NotFound />
                    </AppLayout>
                  }
                />
              </Routes>
            </AnimatePresence>
          </BrowserRouter>
        </AuthModalProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

createRoot(document.getElementById("root")).render(<App />);


