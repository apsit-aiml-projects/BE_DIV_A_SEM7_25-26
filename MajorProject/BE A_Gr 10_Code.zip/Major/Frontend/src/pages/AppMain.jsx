import axios from "axios";
import React, { useRef, useState, useEffect } from "react";
import {
  useAuthModal,
  Button,
  Card,
  CardHeader,
  CardTitle,
  CardContent,
  Textarea,
  Progress,
  summarizeText,
  extractActionItems,
  extractDecisions,
  parseSRT,
  parseVTT,
} from "../main.jsx";
import { Upload, Copy, FileText, FileDown, Printer } from "lucide-react";

export default function AppMain() {
  const { isAuthenticated, openModal } = useAuthModal();
  const [dragging, setDragging] = useState(false);
  const [fileName, setFileName] = useState("");
  const [progress, setProgress] = useState(0);
  const [transcript, setTranscript] = useState([]);
  const [transcriptText, setTranscriptText] = useState("");
  const [summary, setSummary] = useState("");
  const [actions, setActions] = useState([]);
  const [decisions, setDecisions] = useState([]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef(null);
  const BASE_URL = "http://127.0.0.1:8001";


  const handleFiles = async (files) => {
    const f = files?.[0];
    if (!f) return;
    setFileName(f.name);
    setTranscript([]);
    setTranscriptText("");
    setSummary("");
    setProgress(0);
    setLoading(true);

    // Handle audio/video files
    if (/^audio\/|^video\//.test(f.type)) {
      const formData = new FormData();
      formData.append("file", f);

      try {
        // Animate progress bar
        let p = 0;
        const timer = setInterval(() => {
          p += Math.random() * 10 + 5;
          setProgress(Math.min(99, Math.round(p)));
        }, 300);

        // ✅ Call FastAPI backend using BASE_URL
        const res = await axios.post(`${BASE_URL}/process/`, formData, {
          headers: { "Content-Type": "multipart/form-data" },
        });

        clearInterval(timer);
        setProgress(100);

        // ✅ Update from backend response
        setTranscript(res.data.transcript);
        setTranscriptText(Array.isArray(res.data.transcript)
          ? res.data.transcript.map(t => t.text).join("\n")
          : String(res.data.transcript)
        );
        setSummary(res.data.summary);
        setActions(res.data.actions);
        setDecisions(res.data.decisions);
      } catch (err) {
        clearInterval(timer);
        setProgress(0);
        console.error(err);
        alert("Error processing file: " + err.message);
      } finally {
        setLoading(false);
      }
      return;
    }

    // Handle SRT/VTT subtitle files
    if (/\.(srt|vtt)$/i.test(f.name)) {
      const text = await f.text();
      const parsed = /\.srt$/i.test(f.name) ? parseSRT(text) : parseVTT(text);
      setTranscriptText(parsed);
      setTranscript([]);
      setProgress(100);
    }
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  const summarize = async () => {
    if (!isAuthenticated) {
      openModal("signin");
      return;
    }
    if (!transcriptText.trim()) {
      alert("Please upload a file or paste transcript first.");
      return;
    }

    setLoading(true);
    setProgress(0);

    try {
      let p = 0;
      const timer = setInterval(() => {
        p += Math.random() * 10 + 5;
        setProgress(Math.min(99, Math.round(p)));
      }, 300);

      const response = await axios.post(`${BASE_URL}/summarize/`, {
        text: transcriptText
      }, {
        headers: { "Content-Type": "application/json" }
      });

      clearInterval(timer);
      setProgress(100);
      setSummary(response.data.summary);
      setActions(response.data.actions);
      setDecisions(response.data.decisions);
    } catch (err) {
      console.error("Summarization error:", err);
      // Fallback to client-side summarization
      const s = summarizeText(transcriptText, { ratio: 0.3, tone: "concise" });
      setSummary(s);
      setProgress(100);
    } finally {
      setLoading(false);
    }
  };

  const copyAll = async () => {
    try{
    const bundle = `Summary
${summary}

Action Items
- ${actions.join("\n- ")}

Decisions
- ${decisions.join("\n- ")}`;
    await navigator.clipboard.writeText(bundle);
    alert("Copied to clipboard!");
  }catch{
    alert("Failed to copy. Please try manually.");
  }
};

  const downloadFile = (ext) => {
    const name = `meet-summary.${ext}`;
    let content = "";
    if (ext === "txt") {
      content = `SUMMARY
${summary}

ACTION ITEMS
${actions.map((a) => "- " + a).join("\n")}

DECISIONS
${decisions.map((d) => "- " + d).join("\n")}`;
    } else {
      content = `# Summary

${summary}

## Action Items
${actions.map((a) => "- " + a).join("\n")}

## Decisions
${decisions.map((d) => "- " + d).join("\n")}`;
    }
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
  };

  const printPage = () => {
    window.print();
  };

  return (
    <div className="py-10 grid md:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Upload or paste transcript</CardTitle>
        </CardHeader>
        <CardContent>
          <div
            onDragOver={(e) => {
              e.preventDefault();
              if (!loading) setDragging(true);
            }}
            onDragLeave={() => !loading && setDragging(false)}
            onDrop={(e) => {
              if (!loading) onDrop(e);
            }}
            className={`border-2 border-dashed rounded-md p-6 text-center mb-4 transition-colors ${
              dragging ? "border-secondary bg-input" : "border-border"
            }`}
          >
            <Upload className="mx-auto mb-2" />
            <p className="text-sm mb-2">Drag & drop audio/video or .srt/.vtt</p>
            <Button
              variant="outline"
              onClick={() => inputRef.current?.click()}
              disabled={loading}
            >
              Choose File
            </Button>
            <input
              ref={inputRef}
              type="file"
              accept="audio/*,video/*,.srt,.vtt"
              className="hidden"
              onChange={(e) => handleFiles(e.target.files)}
            />
            {fileName && (
              <p className="mt-2 text-xs text-muted">Selected: {fileName}</p>
            )}
          </div>

          

          <div className="flex items-center gap-3">
            <Button onClick={summarize} disabled={loading}>
              {loading ? "Processing..." : "Summarize"}
            </Button>

            
          </div>

          <div className="mt-4">
            <Progress value={progress} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Summary & Exports</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            rows={10}
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            placeholder="Summary will appear here..."
          />
          <div className="flex flex-wrap items-center gap-2 mt-3">
            <Button variant="subtle" onClick={copyAll}>
              <Copy size={16} /> Copy
            </Button>
            <Button variant="subtle" onClick={() => downloadFile("txt")}>
              <FileText size={16} /> TXT
            </Button>
            <Button variant="subtle" onClick={() => downloadFile("md")}>
              <FileDown size={16} /> Markdown
            </Button>
            <Button variant="subtle" onClick={printPage}>
              <Printer size={16} /> PDF
            </Button>
          </div>

          <div className="grid md:grid-cols-2 gap-4 mt-6">
            <div>
              <h4 className="font-semibold mb-2">Action Items</h4>
              <ul className="list-disc list-inside text-sm text-muted space-y-1">
                {actions.length ? (
                  actions.map((a, i) => <li key={i}>{a}</li>)
                ) : (
                  <li>—</li>
                )}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Decisions</h4>
              <ul className="list-disc list-inside text-sm text-muted space-y-1">
                {decisions.length ? (
                  decisions.map((d, i) => <li key={i}>{d}</li>)
                ) : (
                  <li>—</li>
                )}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}


