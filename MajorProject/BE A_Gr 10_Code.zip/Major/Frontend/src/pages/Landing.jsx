import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, Button } from "../main.jsx";
import { Link } from "react-router-dom";
import { Check } from "lucide-react";

export default function Landing() {

  const features = [
    "Local extractive summarization",
    "Action items detection",
    "Decisions extraction",
    "SRT/VTT parsing",
    "Progress simulation",
    "One-click exports"
  ];

  const steps = [
    { t: "Upload or paste transcript", d: "Drag & drop audio/video or paste text." },
    { t: "Simulate transcription", d: "Watch progress as we 'transcribe'." },
    { t: "Get summary & tasks", d: "Copy, export, or print results." }
  ];

  return (
    <div>
      <section className="py-16 md:py-24">
        <div className="text-center max-w-2xl mx-auto">
          <motion.h1
            className="text-4xl md:text-6xl font-extrabold leading-tight mb-4"
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
          >
            Turn meetings into <span className="text-gradient">crisp summaries</span>
          </motion.h1>
          <motion.p
            className="text-muted mb-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            Upload a recording or paste transcripts. Get highlights, action items, and decisions.
          </motion.p>
          <motion.div
            className="flex items-center justify-center gap-3"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Link to="/app" className="inline-block">
              <Button className="px-5 py-3">Get started free</Button>
            </Link>
            <a href="#how" className="px-5 py-3 rounded-md border border-border hover:bg-input">
              See how it works
            </a>
          </motion.div>
        </div>

        <motion.div
          className="mt-12"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="max-w-4xl mx-auto">
            <CardHeader>
              <CardTitle>Demo window</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-48 rounded-md bg-input relative overflow-hidden">
                <div className="absolute inset-0 shimmer" />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </section>

      <section id="features" className="py-12">
        <h2 className="text-2xl font-bold mb-6">Features</h2>
        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
          {features.map((f) => (
            <Card key={f}>
              <CardContent className="flex items-center gap-3">
                <div className="h-8 w-8 rounded-full bg-input flex items-center justify-center">
                  <Check className="text-secondary" size={18} />
                </div>
                <span>{f}</span>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section id="how" className="py-12">
        <h2 className="text-2xl font-bold mb-6">How it works</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {steps.map((s, i) => (
            <Card key={i}>
              <CardHeader><CardTitle>{i + 1}. {s.t}</CardTitle></CardHeader>
              <CardContent className="text-muted">{s.d}</CardContent>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}


