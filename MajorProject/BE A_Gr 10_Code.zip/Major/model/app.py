
import os
import tempfile
import warnings
from fastapi import FastAPI, UploadFile
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from faster_whisper import WhisperModel
from pydub import AudioSegment
from transformers import pipeline
from dotenv import load_dotenv
from huggingface_hub import login

# Suppress warnings
warnings.filterwarnings("ignore", category=UserWarning, module="pyannote")

# Load environment variables
load_dotenv()

class SummarizeRequest(BaseModel):
    text: str

class SummarizeResponse(BaseModel):
    summary: str
    actions: list = []
    decisions: list = []

app = FastAPI()

# Enable CORS for frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

print("🚀 Loading models...")
whisper_model = WhisperModel("base", device="cpu")
hf_token = os.getenv("HUGGINGFACE_TOKEN")
if hf_token:
    try:
        login(hf_token)
        try:
            summarizer = pipeline("summarization", model="facebook/bart-large-cnn")
            print("✅ Advanced summarizer loaded!")
        except Exception:
            summarizer = pipeline("summarization")
            print("✅ Basic summarizer loaded!")
    except Exception as e:
        print(f"⚠️ Hugging Face login failed: {e}")
        summarizer = None
else:
    print("⚠️ No Hugging Face token found - using basic summarization")
    summarizer = None

print("✅ All models loaded successfully!")

def simple_summarize(text: str) -> str:
    action_decision_keywords = ['will', 'should', 'need to', 'follow up', 'assign', 'due', 'next step', 'please', 'action', 'todo', 'decided', 'agreed', 'approved', 'chose', 'concluded', 'finalized', 'decision', 'consensus']
    sentences = [s.strip() for s in text.split('. ') if s.strip()]
    if len(sentences) <= 3:
        return text
    filtered = [s for s in sentences if not any(k in s.lower() for k in action_decision_keywords)]
    pick_from = filtered if filtered else sentences
    summary_sentences = pick_from[:max(1, len(pick_from) // 3)]
    return '. '.join(summary_sentences) + ('.' if not summary_sentences[-1].endswith('.') else '')

def extract_action_items(text: str) -> list:
    lines = text.split('\n')
    keywords = ['will', 'should', 'need to', 'follow up', 'assign', 'due', 'next step', 'please', 'action', 'todo']
    return [l.strip() for l in lines if any(k in l.lower() for k in keywords)][:5]

def extract_decisions(text: str) -> list:
    lines = text.split('\n')
    keywords = ['decided', 'agreed', 'approved', 'chose', 'concluded', 'finalized', 'decision', 'consensus']
    return [l.strip() for l in lines if any(k in l.lower() for k in keywords)][:5]

def convert_to_audio(input_file: str):
    filename, ext = os.path.splitext(input_file)
    if ext.lower() in [".mp4", ".mkv", ".avi"]:
        output_file = f"{filename}.wav"
        audio = AudioSegment.from_file(input_file)
        audio.export(output_file, format="wav")
        return output_file
    return input_file

def diarize_speakers(segments):
    """
    Placeholder for true speaker diarization.
    (Use pyannote.audio or similar for actual diarization in future.)
    For now, returns 'Speaker' for all segments.
    """
    # Example: Assigning all as 'Speaker' (real diarization can replace this)
    return ["Speaker" for _ in segments]

@app.post("/process/")
async def process_file(file: UploadFile):
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=file.filename) as temp:
            temp.write(await file.read())
            temp_path = temp.name

        audio_path = convert_to_audio(temp_path)
        segments, _ = whisper_model.transcribe(audio_path, beam_size=5)
        segments = list(segments)
        # Placeholder speaker diarization:
        speakers = diarize_speakers(segments)
        transcript = [
            {
                "start": s.start,
                "end": s.end,
                "speaker": speakers[i],
                "text": s.text.strip()
            } for i, s in enumerate(segments)
        ]

        full_text = " ".join([t["text"] for t in transcript])
        if len(full_text) > 1000:
            full_text = full_text[:1000] + "..."

        # Summarization
        if summarizer:
            try:
                summary_result = summarizer(full_text, max_length=200, min_length=50, do_sample=False)
                summary_text = summary_result[0]["summary_text"]
            except Exception as e:
                print(f"Summarization error: {e}")
                summary_text = simple_summarize(full_text)
        else:
            summary_text = simple_summarize(full_text)

        # Extract actions and decisions strictly from the original content to avoid summary overlap
        actions = extract_action_items(full_text)
        decisions = extract_decisions(full_text)
        # Keep comprehensive fields for compatibility (same as actions/decisions here)
        all_actions = actions
        all_decisions = decisions

        # Optional debug logs
        with open("transcript.txt", "w", encoding="utf-8") as f:
            f.write("\n".join([f"{t['speaker']}: {t['text']}" for t in transcript]))
        with open("summary.txt", "w", encoding="utf-8") as f:
            f.write(summary_text)

        os.remove(temp_path)
        if audio_path != temp_path and audio_path.endswith(".wav") and os.path.exists(audio_path):
            os.remove(audio_path)

        return {
            "status": "success",
            "transcript": transcript,
            "summary": summary_text,
            "actions": actions,           # Extracted from summary (focused)
            "all_actions": all_actions,   # Extracted from full text (complete)
            "decisions": decisions,       # Extracted from summary (focused)
            "all_decisions": all_decisions # Extracted from full text (complete)
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.post("/summarize/", response_model=SummarizeResponse)
async def summarize_text(request: SummarizeRequest):
    try:
        text = request.text.strip()
        if not text:
            return SummarizeResponse(summary="No text provided.", actions=[], decisions=[])

        if len(text) > 1000:
            text = text[:1000] + "..."

        try:
            if summarizer:
                result = summarizer(text, max_length=200, min_length=50, do_sample=False)
                summary_text = result[0]["summary_text"]
            else:
                summary_text = simple_summarize(text)
        except Exception:
            summary_text = simple_summarize(text)

        # Extract from the original text to ensure they differ from the summary
        actions = extract_action_items(text)
        decisions = extract_decisions(text)

        return SummarizeResponse(summary=summary_text, actions=actions, decisions=decisions)
    except Exception as e:
        return SummarizeResponse(summary=f"Error: {str(e)}", actions=[], decisions=[])

@app.get("/")
def home():
    return {"message": "Backend running and ready for audio summarization and action/decision extraction!"}